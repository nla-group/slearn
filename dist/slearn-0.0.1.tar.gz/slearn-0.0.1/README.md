# slearn


[![Build Status](https://app.travis-ci.com/nla-group/sblearn.svg?token=SziD2n1qxpnRwysssUVq&branch=main)](https://app.travis-ci.com/github/nla-group/sblearn)

A package linking symbolic representation with sklearn for time series prediction
